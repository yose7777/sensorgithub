package com.example.sensorgempa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
