import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sensorgempa/provider/auth_provider.dart'; // Pastikan pathnya benar
import 'package:sensorgempa/screen/home_screen.dart'; // Pastikan pathnya benar
import 'package:sensorgempa/screen/login_screen.dart'; // Pastikan pathnya benar
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart'; // Import untuk FCM

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    if (Firebase.apps.isEmpty) {
      await Firebase.initializeApp(); // Inisialisasi Firebase
    }
  } catch (e) {
    print('Error initializing Firebase: $e');
    // Menampilkan error jika gagal menginisialisasi Firebase
  }

  // Menunggu permintaan izin notifikasi di iOS
  await FirebaseMessaging.instance.requestPermission();

  // Mendapatkan FCM Token
  FirebaseMessaging messaging = FirebaseMessaging.instance;
  String? token = await messaging.getToken();
  print("FCM Token: $token"); // Token untuk pengujian

  // Menangani notifikasi di foreground
  FirebaseMessaging.onMessage.listen((RemoteMessage message) {
    if (message.notification != null) {
      print('Received notification: ${message.notification!.title}');
      print('Notification Body: ${message.notification!.body}');
      // Anda bisa menampilkan dialog atau notifikasi lokal di sini
    }
  });

  // Menangani notifikasi di background
  FirebaseMessaging.onBackgroundMessage(_backgroundMessageHandler);

  runApp(const MyApp());
}

Future<void> _backgroundMessageHandler(RemoteMessage message) async {
  print('Received background message: ${message.messageId}');
  // Tangani logika untuk notifikasi di background di sini
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => authProvider(), // Pastikan AuthProvider sudah benar
        ),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Sensor Gempa',
        darkTheme: ThemeData(
          brightness: Brightness.dark,
          primarySwatch: Colors.blue,
        ),
        themeMode: ThemeMode.dark, // Menetapkan hanya dark theme
        home: StreamBuilder<User?>(
          stream: FirebaseAuth.instance.userChanges(), // Memantau perubahan status user
          builder: (ctx, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              // Menunggu koneksi Firebase untuk status user
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasData) {
              return const HomePage(); // Jika sudah login, tampilkan HomePage
            }
            return const LoginScreen(); // Jika belum login, tampilkan LoginScreen
          },
        ),
      ),
    );
  }
}
