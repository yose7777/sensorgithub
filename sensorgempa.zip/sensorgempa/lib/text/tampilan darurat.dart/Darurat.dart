import 'package:flutter/material.dart';

class HalamanDarurat extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Peringatan Darurat!"),
        // Warna latar belakang AppBar
      ),
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Judul Halaman
              const Text(
                "Gempa Ringan!",
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                  color: Colors
                      .yellow, // Warna teks merah untuk menonjolkan darurat
                ),
              ),
              const SizedBox(height: 20),

              // Deskripsi atau informasi mengenai darurat
              const Text(
                "Terdeteksi adanya gempa bumi. Harap segera menuju ke tempat yang aman dan ikuti prosedur keselamatan yang berlaku.",
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.black,
                ),
              ),
              const SizedBox(height: 30),

              // Gambar atau ikon yang menggambarkan darurat
              Center(
                child: Image.asset(
                  'images/gempa.png', // Ganti dengan path gambar yang sesuai
                  height: 250,
                  width: 250,
                  color: Colors.yellow,
                ),
              ),
              const SizedBox(height: 34),

              // Tombol untuk menutup atau kembali ke halaman sebelumnya
            ],
          ),
        ),
      ),
    );
  }
}
