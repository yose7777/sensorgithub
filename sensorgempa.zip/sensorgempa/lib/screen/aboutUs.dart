
import 'package:flutter/material.dart';


class Aboutus extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Halaman Darurat"),
        backgroundColor: Colors.red, // Warna latar belakang AppBar
      ),);}}