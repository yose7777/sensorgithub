import 'package:flutter/material.dart';

class EarthquakeHistoryPage extends StatefulWidget {
  const EarthquakeHistoryPage({super.key});

  @override
  State<EarthquakeHistoryPage> createState() => _EarthquakeHistoryPageState();
}

class _EarthquakeHistoryPageState extends State<EarthquakeHistoryPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('History of Earthquakes'),
      ),
      body: const Center(
        child: Text('This is the Earthquake History page.'),
      ),
    );
  }
}
