import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/material.dart';
import 'dart:io'; // Untuk menangani file gambar

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final ImagePicker _picker = ImagePicker();
  late File _image; // Variabel untuk menyimpan gambar lokal
  bool _isLoading = false; // Menandakan apakah gambar sedang diupload
  String _imageUrl = ''; // URL gambar yang diupload ke Firebase

  @override
  void initState() {
    super.initState();
    // Cek jika sudah ada URL gambar sebelumnya
    _loadProfileImage();
  }

  // Fungsi untuk memuat gambar profil yang sudah ada (dari Firebase)
  Future<void> _loadProfileImage() async {
    try {
      // Mendapatkan URL gambar yang sudah ada di Firebase Storage
      final String imageUrl =
          await _storage.ref('profile_picture.jpg').getDownloadURL();
      setState(() {
        _imageUrl = imageUrl; // Simpan URL gambar
      });
    } catch (e) {
      print('Error loading image: $e');
    }
  }

  // Fungsi untuk memilih gambar menggunakan image_picker
  Future<void> _pickImage() async {
    final XFile? pickedFile =
        await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
      _uploadImage(); // Upload gambar setelah dipilih
    }
  }

  // Fungsi untuk mengupload gambar ke Firebase Storage
  Future<void> _uploadImage() async {
    setState(() {
      _isLoading = true; // Menandakan bahwa gambar sedang diupload
    });

    try {
      // Mengupload gambar ke Firebase Storage
      final UploadTask uploadTask = _storage
          .ref('profile_picture.jpg') // Nama file gambar di Firebase
          .putFile(_image);

      final TaskSnapshot snapshot = await uploadTask;
      final String downloadUrl = await snapshot.ref.getDownloadURL();

      setState(() {
        _imageUrl = downloadUrl; // Simpan URL gambar yang baru
        _isLoading = false; // Gambar sudah selesai diupload
      });
    } catch (e) {
      print('Error uploading image: $e');
      setState(() {
        _isLoading = false; // Jika gagal, ubah status loading
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueGrey[900], // Latar belakang halaman profil
      appBar: AppBar(
        title: const Text("Profil Pengguna"),
        backgroundColor: Colors.grey[850], // Membuat AppBar transparan
        elevation: 0, // Menghilangkan bayangan pada AppBar
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(children: [
          // Menampilkan foto profil dengan animasi jika sedang mengupload
          GestureDetector(
            onTap: _pickImage,
            child: CircleAvatar(
              radius: 80,
              backgroundColor: Colors.grey[850],
              child: _isLoading
                  ? const CircularProgressIndicator() // Tampilkan loading jika sedang mengupload
                  : _imageUrl.isEmpty
                      ? const Icon(Icons.camera_alt,
                          size: 50, color: Colors.grey)
                      : ClipOval(
                          child: CachedNetworkImage(
                            imageUrl: _imageUrl, // Gambar dari Firebase Storage
                            placeholder: (context, url) =>
                                const CircularProgressIndicator(),
                            errorWidget: (context, url, error) =>
                                const Icon(Icons.error),
                            width: 160,
                            height: 160,
                            fit: BoxFit.cover,
                          ),
                        ),
            ),
          ),
          const SizedBox(height: 20),
          // Nama Pengguna
          const Text(
            'Nama Pengguna', // Gantilah ini dengan nama pengguna yang sesuai
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 10),
          // Email Pengguna

          // Deskripsi singkat tentang pengguna
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 30.0),
            child: Text(
              "Saya seorang developer Flutter yang suka belajar dan berbagi pengetahuan. Saya suka bekerja pada proyek yang menantang dan terus mengembangkan keterampilan saya.",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white60,
                fontSize: 16,
              ),
            ),
          ),
          const SizedBox(height: 30),
          // Tombol untuk memilih gambar
          ElevatedButton.icon(
            onPressed: _pickImage,
            icon: const Icon(Icons.camera_alt),
            label: const Text('Ubah Foto Profil'),
            style: ElevatedButton.styleFrom(
              iconColor: Colors.blueAccent, // Warna tombol
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
              shape: RoundedRectangleBorder(
                borderRadius:
                    BorderRadius.circular(30), // Membuat tombol melengkung
              ),
            ),
          ),
          const SizedBox(height: 20),
        ]),
      ),
    );
  }
}
