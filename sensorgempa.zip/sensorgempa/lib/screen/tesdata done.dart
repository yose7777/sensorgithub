import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// Komponen untuk mengambil data dari Firebase
class FirebaseGetRequest extends StatefulWidget {
  final Function(String)
      onDataReceived; // Callback untuk mengirimkan data ke HomePage

  const FirebaseGetRequest({Key? key, required this.onDataReceived})
      : super(key: key);

  @override
  _FirebaseGetRequestState createState() => _FirebaseGetRequestState();
}

class _FirebaseGetRequestState extends State<FirebaseGetRequest> {
  String _data = "Menunggu data...";

  @override
  void initState() {
    super.initState();
    _getDataFromFirebase();
    _startPolling(); // Memulai polling untuk mendapatkan data secara berkala
  }

  // Fungsi untuk mengambil data dari Firebase Realtime Database menggunakan HTTP GET
  Future<void> _getDataFromFirebase() async {
    const String firebaseUrl =
        'https://sensor-gempa-68ac7-default-rtdb.firebaseio.com/perangkat.json';

    try {
      final response = await http.get(Uri.parse(firebaseUrl));

      if (response.statusCode == 200) {
        final responseBody = response.body;

        if (responseBody.isNotEmpty && responseBody != 'null') {
          final Map<String, dynamic> data = json.decode(response.body);

          setState(() {
            _data = data.toString();
            widget.onDataReceived(_data); // Kirim data ke HomePage
          });
        } else {
          setState(() {
            _data = "Data tidak ditemukan.";
            widget.onDataReceived(_data); // Kirim data ke HomePage
          });
        }
      } else {
        setState(() {
          _data = "Gagal mengambil data. Status: ${response.statusCode}";
          widget.onDataReceived(_data); // Kirim data ke HomePage
        });
      }
    } catch (e) {
      print('Error: $e');
      setState(() {
        _data = "Error terjadi.";
        widget.onDataReceived(_data); // Kirim data ke HomePage
      });
    }
  }

  // Fungsi polling untuk memeriksa data secara berkala
  void _startPolling() {
    Future.delayed(const Duration(seconds: 1), () {
      _getDataFromFirebase();
      _startPolling(); // Terus memanggil polling setiap detik
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Polling HTTP GET Firebase"),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Text(
            _data, // Menampilkan data yang diterima dari Firebase
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 42, // Ukuran font diperbesar menjadi 42
              fontWeight:
                  FontWeight.bold, // Optional: Menambahkan ketebalan font
            ),
          ),
        ),
      ),
    );
  }
}
