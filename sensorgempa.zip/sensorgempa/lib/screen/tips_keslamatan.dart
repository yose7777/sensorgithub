import 'package:flutter/material.dart';

class SafetyTipsPage extends StatefulWidget {
  const SafetyTipsPage({super.key});

  @override
  _SafetyTipsPageState createState() => _SafetyTipsPageState();
}

class _SafetyTipsPageState extends State<SafetyTipsPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Offset> _offsetAnimation;

  @override
  void initState() {
    super.initState();
    // Membuat AnimationController dengan durasi 300ms (lebih cepat)
    _controller = AnimationController(
      duration:
          const Duration(milliseconds: 300), // Menyesuaikan durasi (kecepatan)
      vsync: this,
    );

    // Membuat animasi posisi gambar yang bergetar dengan bergerak lebih jauh di sumbu X
    _offsetAnimation = Tween<Offset>(
      begin: const Offset(0.0, 0.0), // Posisi awal
      end: const Offset(
          0.1, 0.0), // Posisi akhir lebih jauh (lebih besar dari sebelumnya)
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.elasticInOut, // Kurva elastis untuk getaran
    ));

    // Memulai animasi berulang dengan kecepatan lebih cepat
    _controller.repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose(); // Jangan lupa untuk dispose controller
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Tips Keselamatan"),
        backgroundColor: Colors.grey[850],
        elevation: 5.0, // Menambahkan bayangan pada AppBar
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Judul halaman
              const Text(
                "Tips Keselamatan Saat Terjadi Gempa",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors
                      .orangeAccent, // Menggunakan warna cerah untuk judul
                ),
              ),
              const SizedBox(height: 20),

              // Gambar atau ikon terkait gempa yang bergetar
              Center(
                child: SlideTransition(
                  position: _offsetAnimation,
                  child: Image.asset(
                    'images/person.png', // Ganti dengan gambar yang sesuai
                    height: 150,
                    width: 150,
                    color: Colors.yellowAccent,
                  ),
                ),
              ),
              const SizedBox(height: 30),

              // Tips keselamatan yang ditampilkan dengan Card untuk desain yang lebih menarik
              _buildSafetyTip(
                context,
                "Segera cari tempat perlindungan di bawah meja atau benda kokoh lainnya.",
              ),
              _buildSafetyTip(
                context,
                "Jangan berlari keluar rumah selama gempa berlangsung.",
              ),
              _buildSafetyTip(
                context,
                "Jauhi jendela dan benda yang bisa jatuh.",
              ),
              _buildSafetyTip(
                context,
                "Setelah gempa, periksa kondisi sekitar dan hindari tempat-tempat berbahaya.",
              ),
              _buildSafetyTip(
                context,
                "Ikuti instruksi evakuasi dari pihak berwenang.",
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Fungsi untuk membungkus setiap tips dengan Card
  Widget _buildSafetyTip(BuildContext context, String tipText) {
    return Card(
      color: Colors.blueGrey[800], // Warna latar belakang card
      margin: const EdgeInsets.symmetric(vertical: 10),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12.0), // Sudut card lebih membulat
      ),
      elevation: 5.0, // Bayangan card untuk efek 3D
      child: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Text(
          tipText,
          style: const TextStyle(
            fontSize: 16,
            color: Colors
                .white70, // Warna teks untuk kontras dengan latar belakang
          ),
        ),
      ),
    );
  }
}
