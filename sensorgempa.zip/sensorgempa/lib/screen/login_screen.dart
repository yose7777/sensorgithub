import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool isLogin = true;

  // Fungsi untuk login dan registrasi pengguna
  Future<void> _handleAuth(String email, String password) async {
    try {
      if (isLogin) {
        // Proses login dengan email dan password
        UserCredential userCredential = await FirebaseAuth.instance
            .signInWithEmailAndPassword(email: email, password: password);
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Login successful!')));

        // Simpan informasi pengguna ke Firestore setelah login
        await FirebaseFirestore.instance
            .collection('users')
            .doc(userCredential.user?.uid)
            .set({
          'email': email,
          'uid': userCredential.user?.uid,
          'createdAt': Timestamp.now(),
          'isAnonymous': false, // Pengguna bukan anonim
        });
      } else {
        // Proses registrasi dengan email dan password
        UserCredential userCredential = await FirebaseAuth.instance
            .createUserWithEmailAndPassword(email: email, password: password);

        // Simpan informasi pengguna ke Firestore setelah registrasi
        await FirebaseFirestore.instance
            .collection('users')
            .doc(userCredential.user?.uid)
            .set({
          'email': email,
          'uid': userCredential.user?.uid,
          'createdAt': Timestamp.now(),
          'isAnonymous': false, // Pengguna bukan anonim
        });
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Registration successful!')));
      }
    } on FirebaseAuthException catch (e) {
      // Menampilkan pesan error jika login atau registrasi gagal
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(
              '${isLogin ? 'Login' : 'Registration'} failed: ${e.message}')));
    }
  }

  // Fungsi untuk widget form input
  Widget _buildTextField({
    required String label,
    required String hint,
    bool obscureText = false,
    required TextEditingController controller,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(labelText: label, hintText: hint),
      obscureText: obscureText,
      validator: validator,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(225, 29, 29, 29),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Animasi Lottie
              Center(
                child: LottieBuilder.asset('assets/animation/ani.json',
                    height: 300, width: 300, repeat: true),
              ),
              const SizedBox(height: 8),
              Text(
                isLogin ? "Login" : "Register",
                style: const TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                    color: Colors.white),
              ),
              const SizedBox(height: 20),
              Form(
                key: _formKey,
                child: Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Theme.of(context).canvasColor,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: const [
                      BoxShadow(
                          color: Color.fromARGB(255, 7, 68, 118),
                          spreadRadius: 1,
                          blurRadius: 2,
                          offset: Offset(0, 3))
                    ],
                  ),
                  child: Column(
                    children: [
                      _buildTextField(
                        label: 'Email',
                        hint: 'Enter your email',
                        controller: emailController,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Email cannot be empty';
                          }
                          if (!value.contains('@')) {
                            return 'Please enter a valid email';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 15),
                      _buildTextField(
                        label: 'Password',
                        hint: 'Enter your password',
                        obscureText: true,
                        controller: passwordController,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Password cannot be empty';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 15),
                      ElevatedButton(
                        onPressed: () {
                          if (_formKey.currentState?.validate() ?? false) {
                            _handleAuth(
                                emailController.text, passwordController.text);
                          }
                        },
                        child: Text(isLogin ? "Login" : "Register"),
                      ),
                      const SizedBox(height: 15),
                      TextButton(
                        onPressed: () => setState(() => isLogin = !isLogin),
                        child: Text(
                          isLogin
                              ? "Don't have an account? Register"
                              : "Already have an account? Login",
                          style: const TextStyle(color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
