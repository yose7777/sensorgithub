import 'dart:convert';
import 'package:dart_ping/dart_ping.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:flutter_local_notifications/flutter_local_notifications.dart'; // Import notifikasi
import 'package:lottie/lottie.dart';
import 'package:sensorgempa/screen/aboutUs.dart';
import 'package:sensorgempa/screen/riwayatgempa.dart';
import 'package:sensorgempa/screen/provil.dart';
import 'package:sensorgempa/screen/tips_keslamatan.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late String formattedDate;
  late Timer _timer;
  String _pingResult = "Menunggu ping...";
  String notifCondition = "Menunggu data..."; // Set initial value
  String status2 = "Menunggu data...";
  String status3 = "Menunggu data...";
  late FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin;

  // Menyimpan status sebelumnya
  String previousStatus2 = "";
  String previousStatus3 = "";

  @override
  void initState() {
    super.initState();
    _updateTime();
    _getDataFromFirebase();
    _startPolling();
    _startPing(); // Memulai ping ke server saat halaman pertama kali dimuat
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      _updateTime(); // Memperbarui waktu setiap detik
    });

    // Inisialisasi plugin notifikasi
    flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
    var initializationSettingsAndroid =
        const AndroidInitializationSettings('@mipmap/ic_launcher');
    var initializationSettings = InitializationSettings(
      android: initializationSettingsAndroid,
    );
    flutterLocalNotificationsPlugin.initialize(initializationSettings);
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  void _updateTime() {
    var now = DateTime.now();
    var formatter = DateFormat('yyyy-MM-dd HH:mm');
    setState(() {
      formattedDate = formatter.format(now);
    });
  }

  void _startPolling() {
    Future.delayed(const Duration(seconds: 1), () {
      _getDataFromFirebase();
      _startPolling();
    });
  }

  Future<void> _getDataFromFirebase() async {
    const String firebaseUrl =
        'https://sensor-gempa-68ac7-default-rtdb.firebaseio.com/Simulation/SensorModule.json';

    try {
      final response = await http.get(Uri.parse(firebaseUrl));
      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        setState(() {
          notifCondition = data['notifCondition'] ??
              "Data tidak ditemukan"; // Ensure default value
          status2 = data['status2'] ?? "Status 2 tidak tersedia";
          status3 = data['status3'] ?? "Status 3 tidak tersedia";
        });

        // Memeriksa apakah status baru adalah "bahaya" dan status sebelumnya tidak "bahaya"
        if (notifCondition.contains("GempaBahaya") &&
            notifCondition != "GempaBahaya") {
          _showNotification("Peringatan: Status 1 berubah menjadi bahaya!");
        }
        if (status2.contains("bahaya") && previousStatus2 != "bahaya") {
          _showNotification("Peringatan: Status 2 berubah menjadi bahaya!");
        }
        if (status3.contains("bahaya") && previousStatus3 != "bahaya") {
          _showNotification("Peringatan: Status 3 berubah menjadi bahaya!");
        }

        // Update status sebelumnya
        previousStatus2 = status2;
        previousStatus3 = status3;
      } else {
        setState(() {
          notifCondition = status2 = status3 = "Gagal mengambil data.";
        });
      }
    } catch (e) {
      setState(() {
        notifCondition = status2 = status3 = "Terjadi kesalahan.";
      });
      print('Error: $e');
    }
  }

  // Fungsi untuk menampilkan notifikasi
  Future<void> _showNotification(String message) async {
    var androidDetails = const AndroidNotificationDetails(
      'channel_id',
      'channel_name',
      channelDescription: 'description',
      importance: Importance.high,
      priority: Priority.high,
    );
    var notificationDetails = NotificationDetails(android: androidDetails);

    await flutterLocalNotificationsPlugin.show(
      0, // ID notifikasi
      'Peringatan Gempa',
      message,
      notificationDetails,
    );
  }

  // Fungsi untuk mulai ping
  void _startPing() async {
    final ping = Ping('8.8.8.8'); // Gunakan DNS Google (8.8.8.8)

    // Menangani hasil ping
    ping.stream.listen((event) {
      if (event.response == null) {
        setState(() {
          _pingResult = "Ping gagal! Tidak ada response.";
        });
      } else {
        setState(() {
          // Memastikan kita hanya menampilkan angka waktu ping tanpa angka nol di depan
          _pingResult =
              " ${event.response?.time?.toString()} ms"; // Hanya tampilkan waktu ping dalam ms tanpa nol
        });
      }
    }, onError: (e) {
      setState(() {
        _pingResult = "Terjadi kesalahan saat ping: $e"; // Menampilkan error
      });
      print('Error ping: $e'); // Debugging error ping
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Home Detektor Gempa",
          selectionColor: Colors.cyan,
        ),
        backgroundColor: Colors.cyan,
      ),
      backgroundColor: Colors.white,
      drawer: Drawer(
        backgroundColor: Colors.cyan,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.cyan,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(
                    Icons.account_circle,
                    size: 70,
                    color: Colors.black,
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Pendeteksi Gempa",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                    ),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.person, color: Colors.white),
              title: const Text(
                'Profil',
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => const ProfilePage()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.info, color: Colors.white),
              title: const Text(
                'About Us',
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => Aboutus()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.history, color: Colors.white),
              title: const Text(
                'Riwayat Gempa',
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                      builder: (context) => const EarthquakeHistoryPage()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.white),
              title: const Text(
                'Log Out',
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                FirebaseAuth.instance.signOut().then((_) {
                  Navigator.of(context).pushReplacementNamed('/login');
                }).catchError((e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Error: $e')),
                  );
                });
              },
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Card(
                        elevation: 5,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        color: Colors.greenAccent,
                        child: Padding(
                          padding: const EdgeInsets.all(20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Lottie.asset(
                                'assets/animation/wif.json',
                                width: 400,
                                height: 100,
                              ),
                              const SizedBox(height: 10),
                              Text(
                                _pingResult,
                                style: const TextStyle(
                                  fontSize: 16,
                                  color: Colors.white,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Card(
                        elevation: 5,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        color: Colors.cyan,
                        child: Padding(
                          padding: const EdgeInsets.all(20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Lottie.asset(
                                'assets/animation/ok.json',
                                width: 400,
                                height: 100,
                              ),
                              const SizedBox(height: 10),
                              const Text(
                                "Status 1",
                                style: TextStyle(
                                  color: Colors.white70,
                                ),
                              ),
                              Text(
                                notifCondition,
                                style: const TextStyle(
                                  fontSize: 16,
                                  color: Colors.white,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Card(
                        elevation: 5,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        color: Colors.orangeAccent,
                        child: Padding(
                          padding: const EdgeInsets.all(20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Lottie.asset(
                                'assets/animation/ok.json',
                                width: 400,
                                height: 100,
                              ),
                              const SizedBox(height: 10),
                              const Text(
                                "Status 2",
                                style: TextStyle(
                                  color: Colors.white70,
                                ),
                              ),
                              Text(
                                status2,
                                style: const TextStyle(
                                  fontSize: 16,
                                  color: Colors.white,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Card(
                        elevation: 5,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        color: Colors.redAccent,
                        child: Padding(
                          padding: const EdgeInsets.all(20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Lottie.asset(
                                'assets/animation/ok.json',
                                width: 400,
                                height: 100,
                              ),
                              const SizedBox(height: 10),
                              const Text(
                                "Status 3",
                                style: TextStyle(
                                  color: Colors.white70,
                                ),
                              ),
                              Text(
                                status3,
                                style: const TextStyle(
                                  fontSize: 16,
                                  color: Colors.white,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 30),
                Center(
                  // Gunakan widget Center untuk menempatkan tombol di tengah
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const SafetyTipsPage()),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 30),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                    child: const Text(
                      "Tips Keselamatan",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
