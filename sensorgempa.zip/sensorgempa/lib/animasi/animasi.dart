import 'package:flutter/material.dart';

class ShakeIconPage extends StatefulWidget {
  @override
  _ShakeIconPageState createState() => _ShakeIconPageState();
}

class _ShakeIconPageState extends State<ShakeIconPage> with TickerProviderStateMixin {
  // AnimationController untuk animasi getar
  late AnimationController _shakeController;
  late Animation<Offset> _shakeAnimation;

  @override
  void initState() {
    super.initState();
    // Inisialisasi animation controller
    _shakeController = AnimationController(
      duration: const Duration(milliseconds: 500), // Durasi animasi
      vsync: this,
    );

    // Definisikan getaran (Tween) yang akan bergerak di sumbu X (horizontal)
    _shakeAnimation = Tween<Offset>(
      begin: Offset.zero,        // Posisi awal (tidak bergeser)
      end: const Offset(0.1, 0), // Posisi akhir (bergoyang sedikit ke kanan)
    ).animate(CurvedAnimation(
      parent: _shakeController,
      curve: Curves.elasticOut, // Efek getar (elasticOut memberikan efek melambung)
    ));
  }

  @override
  void dispose() {
    _shakeController.dispose(); // Jangan lupa untuk dispose saat widget dibuang
    super.dispose();
  }

  // Fungsi untuk memulai animasi getar
  void _startShake() {
    _shakeController.forward(from: 0.0); // Menjalankan animasi dari awal
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Shake Icon Animation')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Gunakan SlideTransition untuk mengaplikasikan animasi pada icon
            SlideTransition(
              position: _shakeAnimation,
              child: const Icon(
                Icons.notifications,
                size: 100,
                color: Colors.blue,
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _startShake, // Memulai animasi getar saat tombol ditekan
              child: const Text('Shake Icon'),
            ),
          ],
        ),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: ShakeIconPage(),
  ));
}
