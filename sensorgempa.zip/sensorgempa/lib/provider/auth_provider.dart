import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class authProvider with ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final formKey = GlobalKey<FormState>(); // GlobalKey untuk Form

  bool islogin = true;
  String enteredEmail = '';
  String enteredPassword = '';

  // Method untuk toggle login mode
  void toggleLoginMode() {
    islogin = !islogin;
    notifyListeners();
  }

  // Method untuk submit form login/register
  Future<void> submit() async {
    final isValid = formKey.currentState!.validate(); // Validasi form

    if (!isValid) {
      return;
    }

    formKey.currentState!.save(); // Simpan form setelah validasi

    try {
      if (islogin) {
        // Login
        await _auth.signInWithEmailAndPassword(
          email: enteredEmail,
          password: enteredPassword,
        );
      } else {
        // Registrasi
        await _auth.createUserWithEmailAndPassword(
          email: enteredEmail,
          password: enteredPassword,
        );
      }
    } on FirebaseAuthException catch (e) {
      // Tangani kesalahan spesifik FirebaseAuthException
      if (e.code == 'user-not-found') {
        print('No user found for that email.');
      } else if (e.code == 'wrong-password') {
        print('Wrong password provided.');
      } else if (e.code == 'email-already-in-use') {
        print('The email address is already in use.');
      } else {
        print('Firebase Auth Error: ${e.message}');
      }
    } catch (e) {
      print('Unknown error occurred: $e');
    }
  }
}
